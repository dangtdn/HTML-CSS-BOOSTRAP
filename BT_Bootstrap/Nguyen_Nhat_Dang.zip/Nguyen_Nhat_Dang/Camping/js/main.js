$(document).ready(function () {
    $('.content-item h2').counterUp({
        delay: 10,
        time: 1000
    });
});